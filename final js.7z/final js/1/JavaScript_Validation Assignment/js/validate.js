var uname=form1.username.value;
var upwd=form1.password.value;
var repwd=form1.retype_password.value;
function isValidUsername(){
	var flag=true;
	var uname=form1.username.value;
	var re = /^\w+$/;
	var names = /^[A-Za-z]+$/;

		if(uname==""||uname==null)
		{
		document.getElementById("username_err").innerHTML="*Please enter UserName";
 document.form1.username.focus() ;

		flag=false;
		}else if(!names.test(uname)){
	 document.form1.username.focus() ;
	 document.getElementById("username_err").innerHTML = "*only alphabets are allowed";
     	 return false;

	}
else
{
document.getElementById("username_err").innerHTML="";
return true;
}

}

function isValidPassword(){
	var flag=true;
	var upwd=form1.password.value;
	re = /[0-9]/;
	re1 = /[a-z]/;
	 re2 = /[A-Z]/;
		if(upwd==""||upwd==null)
		{
		document.getElementById("password_err").innerHTML="*Please enter Password";
		flag=false;
		}else if(upwd.length < 6) {
      document.getElementById("password_err").innerHTML="Error: Password must contain at least six characters!";
       form1.password.focus();
        return false;
      }else if(!re.test(upwd)) {
        document.getElementById("password_err").innerHTML="Error: password must contain at least one number (0-9)!";
        form1.password.focus();
        return false;
      }else if(!re1.test(upwd)) {
        document.getElementById("password_err").innerHTML="Error: password must contain at least one lowercase letter (a-z)!";
         form1.password.focus();
        return false;
      }else if(!re2.test(upwd)) {
        document.getElementById("password_err").innerHTML="Error: password must contain at least one uppercase letter (A-Z)!";
         form1.password.focus();
        return false;
      }
    else {
     document.getElementById("password_err").innerHTML="You entered a valid password: " + form1.password.value;
    return true;
  }


}

function isCorrectPassword(){
	var flag=true;
	var upwd=form1.password.value;
	var repwd=form1.retype_password.value;

if(repwd==""||repwd==null)
{
document.getElementById("rePassword_err").innerHTML="*Please enter Password same as above";
flag=false;
}
else if(upwd!= "" && upwd!== repwd)
{
document.getElementById("rePassword_err").innerHTML="Entered password and confirm password should be same";
	flag=false;
}
else
{
document.getElementById("rePassword_err").innerHTML="";
	return flag;
}
}

function doCheck(){
    var allFilled = true;
    
    var inputs = document.getElementsByTagName('input');
    for(var i=0; i<inputs.length; i++){
        if((inputs[i].type == "text" || inputs[i].type == "password") && inputs[i].value == '' ){
            allFilled = false;
            break;
        }
    }
    
    document.getElementById("btn").disabled = !allFilled;
}

window.onload = function(){
    var inputs = document.getElementsByTagName('input');
    for(var i=0; i<inputs.length; i++){
        if(inputs[i].type == "text" || inputs[i].type == "password"){
            inputs[i].onkeyup = doCheck;
            inputs[i].onblur = doCheck;
        }
    }
};