package Extra;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * A dirty simple program that reads an Excel file.
 * @author www.codejava.net
 *
 */
public class SimpleExcelReaderExample {
	
	public static void main(String[] args) throws IOException {
		String excelFilePath = "D:\\Books.xlsx";
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		
		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet firstSheet = workbook.getSheetAt(0);
		Iterator<Row> iterator = firstSheet.iterator();
		
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Iterator<Cell> cellIterator = nextRow.cellIterator();
			Book book=new Book();
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				//String title,author;
				double price;
				switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						/*System.out.print(cell.getCellType());*/
					    //title=cell.getStringCellValue();
					   // System.out.print(book);
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						System.out.print(cell.getBooleanCellValue());
						
						break;
					case Cell.CELL_TYPE_NUMERIC:
						System.out.println(cell.getNumericCellValue());
						if(cell.getNumericCellValue()==0)
						{
							/*System.out.println("null value");*/
			                 
						}
						else{
						System.out.print(cell.getNumericCellValue());
						}
						break;
				}
				
				//book.setTitle(title);
				System.out.print(" - ");
			}
		System.out.println();
		}
		
		workbook.close();
		inputStream.close();
	}

	

}
