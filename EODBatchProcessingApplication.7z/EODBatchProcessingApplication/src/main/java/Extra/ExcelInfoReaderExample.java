package Extra;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.sun.rowset.internal.Row;

/**
 * A program demonstrates reading other information of workbook, sheet and cell.
 * @author www.codejava.net
 *
 */
public class ExcelInfoReaderExample {


	public static void main(String[] args) throws IOException {
		String excelFilePath = "D:\\Books.xlsx";
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		
		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet sheet = workbook.getSheetAt(0);
		String sheetName = sheet.getSheetName();
		
		System.out.println("Sheet name = " + sheetName);
		
		int numberOfSheets = workbook.getNumberOfSheets();
		for (int i = 0; i < numberOfSheets; i++) {
			Sheet aSheet = workbook.getSheetAt(i);
			System.out.println(aSheet.getSheetName());
		}
		
		Comment cellComment = sheet.getCellComment(2, 2);
		System.out.println("comment: " + cellComment.getString());
		
		workbook.close();
		inputStream.close();
	}
}
	
	/*public static void main(String[] args) throws IOException {
	    String excelFilePath = "Books.xlsx";
	    ExcelInfoReaderExample reader = new ExcelInfoReaderExample();
	    List<Book> listBooks = reader.readBooksFromExcelFile(excelFilePath);
	    System.out.println(listBooks);
	}

	private List<Book> readBooksFromExcelFile(String excelFilePath) throws IOException  {
		List<Book> listBooks = new ArrayList<>();
	    FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
	 
	    Workbook workbook = new XSSFWorkbook(inputStream);
	    Sheet firstSheet = workbook.getSheetAt(0);
	    Iterator<org.apache.poi.ss.usermodel.Row> iterator = firstSheet.iterator();
	 
	    while (iterator.hasNext()) {
	        Row nextRow = (Row) iterator.next();
	        Iterator<Cell> cellIterator = ((org.apache.poi.ss.usermodel.Row) nextRow).cellIterator();
	        Book aBook = new Book();
	 
	        while (cellIterator.hasNext()) {
	            Cell nextCell = cellIterator.next();
	            int columnIndex = nextCell.getColumnIndex();
	 
	            switch (columnIndex) {
	            case 1:
	                aBook.setTitle((String) getCellValue(nextCell));
	                break;
	            case 2:
	                aBook.setAuthor((String) getCellValue(nextCell));
	                break;
	            case 3:
	                aBook.setPrice( getCellValue(nextCell));
	                break;
	            }
	 
	 
	        }
	        listBooks.add(aBook);
	    }
	 
	    workbook.close();
	    inputStream.close();
	 
	    return listBooks;
	}

	private String getCellValue(Cell nextCell) {
		// TODO Auto-generated method stub
		return null;
	}
	}
*/

