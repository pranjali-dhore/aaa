package org.pojo;

import java.util.Date;

public class EODBatchProcessCutomer {

	private int card_no;
	private int cust_id;
	private String date_of_transaction;
	private double amount_debited;
	private double amount_credited;
	private double net_amount;
	
	
	public EODBatchProcessCutomer() {
		super();
	}
	public EODBatchProcessCutomer(int card_no, int cust_id, String date_of_transaction, double amount_debited,
			double amount_credited, double net_amount) {
		super();
		this.card_no = card_no;
		this.cust_id = cust_id;
		this.date_of_transaction = date_of_transaction;
		this.amount_debited = amount_debited;
		this.amount_credited = amount_credited;
		this.net_amount = net_amount;
	}
	public int getCard_no() {
		return card_no;
	}
	public int getCust_id() {
		return cust_id;
	}
	public String getDate_of_transaction() {
		return date_of_transaction;
	}
	public double getAmount_debited() {
		return amount_debited;
	}
	public double getAmount_credited() {
		return amount_credited;
	}
	public double getNet_amount() {
		return net_amount;
	}
	public void setCard_no(int card_no) {
		this.card_no = card_no;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public void setDate_of_transaction(String date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}
	public void setAmount_debited(double amount_debited) {
		this.amount_debited = amount_debited;
	}
	public void setAmount_credited(double amount_credited) {
		this.amount_credited = amount_credited;
	}
	public void setNet_amount(double net_amount) {
		this.net_amount = net_amount;
	}
	@Override

	public String toString() {
		return "card_no=" + card_no + ", cust_id=" + cust_id + ", date_of_transaction="
				+ date_of_transaction + ", amount_debited=" + amount_debited + ", amount_credited=" + amount_credited
				+ ", net_amount=" + net_amount;
	}
	
	
	
	
	
}
