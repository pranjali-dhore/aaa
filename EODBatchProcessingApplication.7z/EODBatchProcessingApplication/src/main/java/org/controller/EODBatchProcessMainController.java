package org.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.EOD.EODBatchProcessExcelRead;
import org.EOD.EODBatchValidator;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.pojo.EODBatchProcessCutomer;
import org.service.EODBatchProcessServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EODBatchProcessMainController {
	
	@RequestMapping("/EODBatch")
	public ModelAndView sayHello(){
		return new ModelAndView("EODBatchProcessSucessPage","message","EOD");
	}
	
//......................LoginController...........................
	@RequestMapping("/login")  
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) {  
        String name=request.getParameter("name");  
        String password=request.getParameter("password");  
       
        if(password.equals("admin")){  
        String message = "Hi "+name+"Login Successful";  
        return new ModelAndView("EODBatchProcessLoginSuccessPage", "message", message);  
        }  
        else{  
            return new ModelAndView("EODBatchProcessLoginErrorPage", "message","Sorry, username or password error");  
        }  
    } 
	

	
	
//..............................Main Controller .......................................

	/*@RequestMapping("/trigger")  
	    public ModelAndView ReadExcelFile(HttpServletRequest request,HttpServletResponse res)  {  
		EODBatchProcessExcelRead eodprocessexcelread = new EODBatchProcessExcelRead();
		FileInputStream inputStream = null;
		String excelFilePath = null;
		eodprocessexcelread.getWorkbook(inputStream, excelFilePath);
		System.out.println(eodprocessexcelread);
		
		public List<EODBatchProcessCutomer> readCustFromExcelFile(String excelFilePath) throws IOException {
		List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
		
		/*final Logger logger = Logger.getLogger(EODBatchProcessExcelRead.class);*/
	
	
	@RequestMapping("/trigger")
	public ModelAndView readCustFromExcelFile(HttpServletRequest req, HttpServletResponse res , String excelFilePath) throws IOException {
		
		
		EODBatchProcessServiceImplementation eod = new EODBatchProcessServiceImplementation();
		List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
	
		File file = new File("D:\\Customer");
        File[] files = file.listFiles();
        for(int i=1;i<=files.length;i++)
		{
        	excelFilePath = "D:\\Customer\\Customer"+i+".xlsx";
		
		 EODBatchProcessServiceImplementation reader = new EODBatchProcessServiceImplementation();
			List<EODBatchProcessCutomer> listCustomer = reader.readCustFromExcelFile(excelFilePath);
			
			System.out.println();
			System.out.println("Customer - "+i);
			System.out.println("Card no\t\t\tCustomer ID\t\t\tDate Of Transaction\t\t\tAmount Debited\t\t\tAmount Credited\t\t\tnetAmount");
			for(EODBatchProcessCutomer EODCustomer:listCustomer)
				System.out.println(EODCustomer.getCard_no()+"\t\t\t"+EODCustomer.getCust_id()+"\t\t\t"+EODCustomer.getDate_of_transaction()+"\t\t\t"+EODCustomer.getAmount_debited()+"\t\t\t"+EODCustomer.getAmount_credited()+"\t\t\t"+EODCustomer.getNet_amount());
			
			
		}
		return new ModelAndView();
	
	}
	
		
@RequestMapping("/cust")
    public ModelAndView GenerateReport(@ModelAttribute("cust") EODBatchProcessCutomer cust,String excelFilePath) throws IOException{
		

	
		EODBatchProcessServiceImplementation eod = new EODBatchProcessServiceImplementation();
		List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
		ModelAndView result = new ModelAndView("EODBatchProcessSaveHtml");
		File file = new File("D:\\Customer");
        File[] files = file.listFiles();
       //list of customer
        
        Map FileMap=new HashMap<>();
        
        for(int i=1;i<=files.length;i++)
		{
        	excelFilePath = "D:\\Customer\\Customer"+i+".xlsx";
       	        	
        	EODBatchProcessServiceImplementation reader = new EODBatchProcessServiceImplementation();
			List<EODBatchProcessCutomer> listCustomer = reader.readCustFromExcelFile(excelFilePath);
			System.out.println();
			System.out.println("Customer - "+i);
			System.out.println("Card no\t\t\tCustomer ID\t\t\tDate Of Transaction\t\t\tAmount Debited\t\t\tAmount Credited\t\t\tnetAmount");
			List<EODBatchProcessCutomer> File_customer_list=new ArrayList<>();
			
			//EODBatchProcessCutomer EODCustomer1 = new EODBatchProcessCutomer();
			for(EODBatchProcessCutomer EODCustomer:listCustomer)
			{
				//file data starts here for every row
				System.out.println(EODCustomer.getCard_no()+"\t\t\t"+EODCustomer.getCust_id()+"\t\t\t"+EODCustomer.getDate_of_transaction()+"\t\t\t"+EODCustomer.getAmount_debited()+"\t\t\t"+EODCustomer.getAmount_credited()+"\t\t\t"+EODCustomer.getNet_amount());
				EODBatchProcessCutomer customer = new EODBatchProcessCutomer();
				customer.setCard_no(EODCustomer.getCard_no());
				customer.setCust_id(EODCustomer.getCust_id());
				customer.setDate_of_transaction(EODCustomer.getDate_of_transaction());
				customer.setAmount_debited(EODCustomer.getAmount_debited());
				customer.setAmount_credited(EODCustomer.getAmount_credited());
				customer.setNet_amount(EODCustomer.getNet_amount());
				File_customer_list.add(customer);
			}
			//Ad the data of the file into the bigger Map.
			FileMap.put(excelFilePath, File_customer_list);
			//FileMap.put("list", File_customer_list);
		
	}
       //result.addObject(FileMap); 
      
        result.addObject("filemap", FileMap);      
      // result.addObject("filemap", FileMap);
       System.out.println(FileMap); 
        return result;  
        
        
}

	
}
	

