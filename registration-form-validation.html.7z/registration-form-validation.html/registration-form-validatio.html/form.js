function Submit(){
	var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/; 
	var phoneRegex = /^\d{10}$/; 
	var names = /^[A-Za-z]+$/;  
	var fname = document.form.Name.value,
		lname = document.form.LastName.value,
		phone_no = document.form.phone.value;
		femail = document.form.Email.value;
		
		
		
	if( fname == "" )
   	{
         document.form.Name.focus() ;
	 document.getElementById("errorBox").innerHTML = "*Please Enter the first name";
     	 return false;
   	}else if(!names.test(fname)){
	 document.form.Name.focus() ;
	 document.getElementById("errorBox").innerHTML = "*Please Enter the first name";
     	 return false;

	}

	
	if( lname == "" )
   	{
     	  document.form.LastName.focus() ;
	  document.getElementById("errorBox").innerHTML = "*Please Enter the last name";
          return false;
   	}else if(!names.test(lname)){
	 document.form.Name.focus() ;
	 document.getElementById("errorBox").innerHTML = "*Please Enter the last name";
     	 return false;

	}
	
	if(phone_no == ""){
	  document.form.phone.focus();
	  document.getElementById("errorBox").innerHTML = "*Please Enter the Phone No.";
          return false;
	
	}else if(!phoneRegex.match(phone_no)){
		document.form.phone.focus();
		document.getElementById("errorBox").innerHTML = "*Please Enter the valid Phone No.";
		return false;
	 }
   
   	if (femail == "" )
	{
		document.form.Email.focus();
		document.getElementById("errorBox").innerHTML = "*Please Enter the Email ID";
		return false;
	 }else if(!emailRegex.match(femail)){
		document.form.Email.focus();
		document.getElementById("errorBox").innerHTML = "*Please Enter the valid Email ID";
		return false;
	 }
	 
	 
	 
	if(document.form.radiobutton[0].checked == false && document.form.radiobutton[1].checked == false){
			document.getElementById("errorBox").innerHTML = "select your gender";
			return false;
			}
	if(fname != '' && lname != '' && phone_no != '' && femail != ''){
			document.getElementById("errorBox").innerHTML = "form submitted successfully";
			}
		  
}

