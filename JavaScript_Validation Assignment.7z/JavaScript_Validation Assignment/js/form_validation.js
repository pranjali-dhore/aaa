
function isValidUsername(){
	var flag=true;
	var uname=form1.username.value;
	var re = /^\w+$/;
	var names = /^[A-Za-z]+$/;

		if(uname==""||uname==null)
		{
		document.getElementById("username_err").innerHTML="*Please enter UserName";
		flag=false;
		}else if(!names.test(uname)){
	 document.form1.username.focus() ;
	 document.getElementById("username_err").innerHTML = "*only alphabets are allowed";
     	 return false;

	}
else
{
document.getElementById("username_err").innerHTML="";
return true;
}

}

function isValidFirstName(){
	
	var flag=true;
	var names = /^[A-Za-z]+$/;  
	var fname = form.first_name.value;	
	if( fname == "" && fname == null )
   	{  
	 document.getElementById("fn_div").innerHTML = "*First name should not be null";
 document.form.first_name.focus() ;
     	 flag= false;
   	}
else if(!names.test(fname)){
	 document.form.first_name.focus() ;
	 document.getElementById("fn_div").innerHTML = "*only alphabets are allowed";
     	 return false;

	}
else
{

document.getElementById("fn_div").innerHTML = "";
		return true;
}
}
	


function isValidLastName(){
	var names = /^[A-Za-z]+$/;
	var lname = document.form.last_name.value;
	if( lname == "" && lname == null)
   	{
     	  document.form.last_name.focus() ;
	  document.getElementById("ln_div").innerHTML = "*Last name should not be null";

          return false;
   	}else if(!names.test(lname)){
	 document.form.last_name.focus() ;
	 document.getElementById("ln_div").innerHTML = "*Please Enter the last name";
     	 return false;

	}
else
{
document.getElementById("ln_div").innerHTML = "";
		return true;

}
}

function isValidPhoneNo(){
		
	var phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
	var phone_no = document.form.phone.value;

	if(phone_no == "" && phone_no == null){
	  document.form.phone.focus();
	  document.getElementById("phone_div").innerHTML = "*Phone No should not be null and should be 10 digits.";
          return false;
	
	}else if(!phoneRegex.test(phone_no)){
		document.form.phone.focus();
		document.getElementById("phone_div").innerHTML = "*Please Enter the valid Phone No.";
		return false;
	 }
else
{
document.getElementById("phone_div").innerHTML = "";
		return true;
}
   }

function isVAlidEmail(){

	var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/; 
	var femail = document.form.email.value;
   	if (femail == "" && femail == null)
	{
		document.form.email.focus();
		document.getElementById("email_div").innerHTML = "*Please Enter the Email ID";
		return false;
	 }else if(!emailRegex.test(femail)){
		document.form.email.focus();
		document.getElementById("email_div").innerHTML = "*Please Enter the valid Email ID";
		return false;
	 }
else
{
document.getElementById("email_div").innerHTML = "";		return true;
}
}



	 
	/*if(document.form.radiobutton[0].checked == false && document.form.radiobutton[1].checked == false){
			document.getElementById("errorBox").innerHTML = "select your gender";
			return false;
			}
	if(fname != '' && lname != '' && phone_no != '' && femail != ''){
			alert("form submitted successfully");
			}*/
		  


function doCheck(){
    var allFilled = true;
    
    var inputs = document.getElementsByTagName('input');
    for(var i=0; i<inputs.length; i++){
        if((inputs[i].type == "text" || inputs[i].type == "radio") && inputs[i].value == ''){
            allFilled = false;
            break;
        }
    }
    
    document.getElementById("btn").disabled = !allFilled;
}

window.onload = function(){
    var inputs = document.getElementsByTagName('input');
    for(var i=0; i<inputs.length; i++){
        if(inputs[i].type == "text" || inputs[i].type == "radio"){
            inputs[i].onkeyup = doCheck;
            inputs[i].onblur = doCheck;
        }
    }
};
