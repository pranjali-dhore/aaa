package com.mkyong.common.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mkyong.common.pojo.EODBatchProcessCutomer;
import com.mkyong.common.service.EODBatchProcessServiceImplementation;

@Controller
public class WelcomeController {

	private static final Logger logger = Logger.getLogger(WelcomeController.class);

	
	
	//......................LoginController...........................
		@RequestMapping("/login")  
	    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) {  
	        String name=request.getParameter("name");  
	        String password=request.getParameter("password");  
	       
	        if(password.equals("admin")){  
	        String message = "Hi "+name+"Login Successful";  
	        return new ModelAndView("EODBatchProcessLoginSuccessPage", "message", message);  
	        }  
	        else{  
	            return new ModelAndView("EODBatchProcessLoginErrorPage", "message","Sorry, username or password error");  
	        }  
	    } 
		

	//@RequestMapping(value = "/hello", method = RequestMethod.GET)
	@RequestMapping("/hello")
	/*public ModelAndView getWelcome() {

		//logs debug message
		if(logger.isDebugEnabled()){
			logger.debug("getWelcome is executed!");
		}
		
		//logs exception
		logger.error("This is Error message", new Exception("Testing"));
		
		ModelAndView model = new ModelAndView("index");
		model.addObject("msg", "Hello Spring MVC + Log4j");
		return model;
	}
	*/
	
	
	public ModelAndView readCustFromExcelFile(HttpServletRequest req, HttpServletResponse res , String excelFilePath) throws IOException {
		
		EODBatchProcessServiceImplementation eod = new EODBatchProcessServiceImplementation();
		List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
		File file = new File("D:\\Customer");
        File[] files = file.listFiles();
        for(int i=1;i<=files.length;i++)
		{
        	excelFilePath = "D:\\Customer\\Customer"+i+".xlsx";
        	EODBatchProcessServiceImplementation reader = new EODBatchProcessServiceImplementation();
			List<EODBatchProcessCutomer> listCustomer = reader.readCustFromExcelFile(excelFilePath);
			System.out.println();
			System.out.println("Customer - "+i);
			System.out.println("Card no\t\t\tCustomer ID\t\t\tDate Of Transaction\t\t\tAmount Debited\t\t\tAmount Credited\t\t\tnetAmount");
			for(EODBatchProcessCutomer EODCustomer:listCustomer)
				System.out.println(EODCustomer.getCard_no()+"\t\t\t"+EODCustomer.getCust_id()+"\t\t\t"+EODCustomer.getDate_of_transaction()+"\t\t\t"+EODCustomer.getAmount_debited()+"\t\t\t"+EODCustomer.getAmount_credited()+"\t\t\t"+EODCustomer.getNet_amount());
			}
		

       
      final Logger errorlog = Logger.getLogger("errorlogger");
		final Logger successlog = Logger.getLogger("successlogger");
		
		for(int i=1;i<=files.length;i++)
		{
        	excelFilePath = "D:\\Customer\\Customer"+i+".xlsx";
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		Workbook workbook = eod.getWorkbook(inputStream, excelFilePath);
		Sheet firstSheet = workbook.getSheetAt(0);   // Loop for Multi
		Iterator<Row> iterator = firstSheet.iterator();
		
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Iterator<Cell> cellIterator = nextRow.cellIterator();
			EODBatchProcessCutomer eodcustomer = new EODBatchProcessCutomer();
			
			while (cellIterator.hasNext()) {
				Cell nextCell = cellIterator.next();
				
			    boolean flag=false;
				int columnIndex = nextCell.getColumnIndex();
				
				switch (columnIndex) {
				case 0:
					
					Double cardno= (Double) eod.getCellValue(nextCell);
					Integer card_no=cardno.intValue();
					
					flag=EODBatchValidator.isEmptyCardNo((int)card_no);
					
					if(flag)
					{
					eodcustomer.setCard_no(card_no);
					
					}
					else{
						errorlog.error("Missing Card Number");
						
					}
					break;
				case 1:
					
					Double custId= (Double) eod.getCellValue(nextCell);
					Integer cust_id=custId.intValue();
					flag=EODBatchValidator.isEmptyCustId((int)cust_id);
					
					if(flag){	
					eodcustomer.setCust_id(cust_id);
				
					}
					else{
						errorlog.error("Missing Customer Id");
						
					
					}
					break;
				case 2:
				
						flag=EODBatchValidator.isEmptyDate((String) eod.getCellValue(nextCell));
					
					if(flag){
						
						eodcustomer.setDate_of_transaction((String) eod.getCellValue(nextCell));
					
					}
					else{
						errorlog.error("Missing Date of Transaction");
						
					}
					break;
				case 3:
					flag=EODBatchValidator.isEmptyAmountDebited((double) eod.getCellValue(nextCell) );
				if(flag){
					
					eodcustomer.setAmount_debited((double) eod.getCellValue(nextCell) );
					
				}
				else{
					errorlog.error("Missing Ammount Debited");
					
				}
					
					break;
				case 4:
			
					flag=EODBatchValidator.isEmptyAmountCredited((double) eod.getCellValue(nextCell) );
					if(flag)
					{
						
						eodcustomer.setAmount_credited((double) eod.getCellValue(nextCell));
						
					}
					else
					{
						errorlog.error("Missing Ammount Credited");
						
				
					}
					break;
				case 5:
                 flag=EODBatchValidator.isEmptyNetAmount((double) (eod.getCellValue(nextCell)) );
					if(flag)
					{
						eodcustomer.setNet_amount( (double) eod.getCellValue(nextCell));
						
					}
					else{
						errorlog.error("Missing Net Ammount");
						
					}
					break;
				}
				if(eodcustomer.getCard_no()!=0 && eodcustomer.getCust_id()!=0 && eodcustomer.getDate_of_transaction()!=null && eodcustomer.getAmount_debited()!=0 && eodcustomer.getAmount_credited()!=0 && eodcustomer.getNet_amount()!=0)
				{
					successlog.info("successfull");
					
				}
				
			}
		
			listCustomerTemp.add(eodcustomer);
			System.out.println(eodcustomer);
			
		}
		
		
		workbook.close();
		inputStream.close();
		
	}
		ModelAndView model = new ModelAndView("EODBatchProcessSucessPage");
		return model;
	}



}
	
		
	