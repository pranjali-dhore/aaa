package com.mkyong.common.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mkyong.common.Dao.EODBatchProcessDaoImplementation;
import com.mkyong.common.pojo.EODBatchProcessCutomer;

@Service

public class EODBatchProcessServiceImplementation implements EODBatchProcessServiceInterface {

	@Autowired
	EODBatchProcessDaoImplementation daoimpl = new EODBatchProcessDaoImplementation();
	@Override
	public Workbook getWorkbook(FileInputStream inputStream, String excelFilePath) throws IOException {
		
		return daoimpl.getWorkbook(inputStream, excelFilePath);
	}

	@Override
	public Object getCellValue(Cell cell) {
		// TODO Auto-generated method stub
		return daoimpl.getCellValue(cell);
	}

	@Override
	public List<EODBatchProcessCutomer> readCustFromExcelFile(String excelFilePath) throws IOException {
		// TODO Auto-generated method stub
		return daoimpl.readCustFromExcelFile(excelFilePath);
	}

}