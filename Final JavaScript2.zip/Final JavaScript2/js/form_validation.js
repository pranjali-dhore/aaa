function isValidFirstName(){
	
	var names = /^[A-Za-z]+$/;
	  
	var fname = document.form.first_name.value;		
		
	if( fname == "" && fname == null )
   	{
         document.form.first_name.focus() ;
	 document.getElementById("fn_div").innerHTML = "*Please Enter the first name";
     	 return false;
   	}else if(!names.test(fname)){
	 document.form.first_name.focus() ;
	 document.getElementById("fn_div").innerHTML = "*Please Enter the first name";
     	 return false;

	}
}
	


function isValidLastName(){
	var names = /^[A-Za-z]+$/;
	var lname = document.form.last_name.value;
	if( lname == "" && lname == null)
   	{
     	  document.form.last_name.focus() ;
	  document.getElementById("ln_div").innerHTML = "*Please Enter the last name";
          return false;
   	}else if(!names.test(lname)){
	 document.form.last_name.focus() ;
	 document.getElementById("ln_div").innerHTML = "*Please Enter the last name";
     	 return false;

	}
}

function isValidPhoneNo(){
		
	var phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
	var phone_no = document.form.phone.value;

	if(phone_no == "" && phone_no == null){
	  document.form.phone.focus();
	  document.getElementById("phone_div").innerHTML = "*Please Enter the Phone No.";
          return false;
	
	}else if(!phoneRegex.test(phone_no)){
		document.form.phone.focus();
		document.getElementById("phone_div").innerHTML = "*Please Enter the valid Phone No.";
		return false;
	 }
   }

function isVAlidEmail(){

	var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/; 
	var femail = document.form.email.value;
   	if (femail == "" && femail == null)
	{
		document.form.email.focus();
		document.getElementById("email_div").innerHTML = "*Please Enter the Email ID";
		return false;
	 }else if(!emailRegex.test(femail)){
		document.form.email.focus();
		document.getElementById("email_div").innerHTML = "*Please Enter the valid Email ID";
		return false;
	 }
	 
	 }



	 
	/*if(document.form.radiobutton[0].checked == false && document.form.radiobutton[1].checked == false){
			document.getElementById("errorBox").innerHTML = "select your gender";
			return false;
			}
	if(fname != '' && lname != '' && phone_no != '' && femail != ''){
			alert("form submitted successfully");
			}*/
		  


function doCheck(){
    var allFilled = true;
    
    var inputs = document.getElementsByTagName('input');
    for(var i=0; i<inputs.length; i++){
        if((inputs[i].type == "text" || inputs[i].type == "radio") && inputs[i].value == ''){
            allFilled = false;
            break;
        }
    }
    
    document.getElementById("btn").disabled = !allFilled;
}

window.onload = function(){
    var inputs = document.getElementsByTagName('input');
    for(var i=0; i<inputs.length; i++){
        if(inputs[i].type == "text" || inputs[i].type == "radio"){
            inputs[i].onkeyup = doCheck;
            inputs[i].onblur = doCheck;
        }
    }
};
